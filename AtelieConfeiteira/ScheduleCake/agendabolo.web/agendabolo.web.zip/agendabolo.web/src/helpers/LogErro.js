const LogErro = (error, message) => {
  console.log(error, message);
};

export default LogErro;
