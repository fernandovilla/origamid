<template>
  <button-large class="btn btn-primary" label="Salvar">
    <font-awesome-icon icon="fa-solid fa-save" />
  </button-large>
</template>

<script>
import ButtonLarge from '@/components/Button/ButtonLarge.vue';

export default {
  name: 'button-large-save',
  components: { ButtonLarge }  
}
</script>

<style>

</style>