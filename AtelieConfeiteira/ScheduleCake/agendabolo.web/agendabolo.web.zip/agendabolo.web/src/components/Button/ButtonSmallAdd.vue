<template>
  <button-small>
    <font-awesome-icon icon="fa-sharp fa-solid fa-circle-plus" class="icon" />
  </button-small>
</template>

<script>
import ButtonSmall from '@/components/Button/ButtonSmall.vue'

export default {
  name:'button-small-add',  
  components: {
    ButtonSmall
  }
}
</script>