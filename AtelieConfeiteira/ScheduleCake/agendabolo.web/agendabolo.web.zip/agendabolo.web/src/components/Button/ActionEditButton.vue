<template>
  <button class="btn btn-action edit">
    <font-awesome-icon icon="fa-solid fa-pen" />
  </button>
</template>

<script>
export default {
  name: 'action-edit-button'
}
</script>

