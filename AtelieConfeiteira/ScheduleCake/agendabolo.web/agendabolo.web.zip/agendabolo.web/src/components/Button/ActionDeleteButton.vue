<template>
  <button class="btn btn-action delete">    
    <font-awesome-icon icon="fa-solid fa-trash" />
  </button>
</template>

<script>
export default {
  name: 'action-delete-button'
}
</script>

<style>

</style>