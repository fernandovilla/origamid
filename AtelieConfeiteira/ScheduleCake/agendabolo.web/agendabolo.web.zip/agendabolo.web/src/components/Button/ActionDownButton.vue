<template>
  <button class="btn btn-action down">    
    <font-awesome-icon icon="fa-solid fa-caret-down" />
  </button>
</template>

<script>
export default {
  name: 'action-up-button'
}
</script>

<style>

</style>