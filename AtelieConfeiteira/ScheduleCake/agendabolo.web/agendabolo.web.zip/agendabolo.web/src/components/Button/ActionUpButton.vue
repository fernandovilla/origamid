<template>
  <button class="btn btn-action up">    
    <font-awesome-icon icon="fa-solid fa-caret-up" />
  </button>
</template>

<script>
export default {
  name: 'action-up-button'
}
</script>

<style>

</style>