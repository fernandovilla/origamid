<template>
  <button-small>
    <font-awesome-icon icon="fa-solid fa-print" />
  </button-small>
</template>

<script>
import ButtonSmall from '@/components/Button/ButtonSmall.vue'

export default {
  name:'button-small-print',  
  components: {
    ButtonSmall
  }
}
</script>

<style scoped>

</style>