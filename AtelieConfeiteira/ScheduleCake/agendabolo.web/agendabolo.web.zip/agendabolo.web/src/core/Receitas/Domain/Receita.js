export default class Receita {
  constructor() {}

  id = 0;
  nome = '';
  descricao = '';
  status = 0;
  observcao = '';
  preparo = '';
  tempopreparo = 0;
  pesoReferencia = 0;
  ingredientes = null; //array
}
