<template>
  <div>
    <p>Desenvolver...</p>
  </div>
</template>

<script>
export default {
  name: "adicionar-nutriente"
}
</script>

<style>

</style>