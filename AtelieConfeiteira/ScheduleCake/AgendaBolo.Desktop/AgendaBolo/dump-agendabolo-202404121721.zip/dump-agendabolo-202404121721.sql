--
-- PostgreSQL database dump
--

-- Dumped from database version 14.10
-- Dumped by pg_dump version 14.10

-- Started on 2024-04-12 17:21:48

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 3 (class 2615 OID 2200)
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- TOC entry 3351 (class 0 OID 0)
-- Dependencies: 3
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 214 (class 1259 OID 263630)
-- Name: embalagensingredientes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.embalagensingredientes (
    id integer NOT NULL,
    idingrediente integer,
    descricao text NOT NULL,
    ean text,
    idunidademedida integer,
    tipoembalagem integer DEFAULT 0,
    quantidade integer
);


ALTER TABLE public.embalagensingredientes OWNER TO postgres;

--
-- TOC entry 213 (class 1259 OID 263629)
-- Name: embalagensingredientes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.embalagensingredientes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.embalagensingredientes_id_seq OWNER TO postgres;

--
-- TOC entry 3352 (class 0 OID 0)
-- Dependencies: 213
-- Name: embalagensingredientes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.embalagensingredientes_id_seq OWNED BY public.embalagensingredientes.id;


--
-- TOC entry 216 (class 1259 OID 263650)
-- Name: estoqueingredientes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.estoqueingredientes (
    id integer NOT NULL,
    idingrediente integer NOT NULL,
    lote text,
    datafabricacao timestamp without time zone,
    datavalidade timestamp without time zone,
    quantidade numeric NOT NULL
);


ALTER TABLE public.estoqueingredientes OWNER TO postgres;

--
-- TOC entry 215 (class 1259 OID 263649)
-- Name: estoqueingredientes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.estoqueingredientes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.estoqueingredientes_id_seq OWNER TO postgres;

--
-- TOC entry 3353 (class 0 OID 0)
-- Dependencies: 215
-- Name: estoqueingredientes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.estoqueingredientes_id_seq OWNED BY public.estoqueingredientes.id;


--
-- TOC entry 210 (class 1259 OID 263600)
-- Name: ingredientes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ingredientes (
    id integer NOT NULL,
    nome text NOT NULL,
    precocusto numeric DEFAULT 0,
    precocustomedio numeric DEFAULT 0,
    quantidadeembalagem numeric DEFAULT 0,
    status smallint DEFAULT 0
);


ALTER TABLE public.ingredientes OWNER TO postgres;

--
-- TOC entry 209 (class 1259 OID 263599)
-- Name: ingredientes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ingredientes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ingredientes_id_seq OWNER TO postgres;

--
-- TOC entry 3354 (class 0 OID 0)
-- Dependencies: 209
-- Name: ingredientes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ingredientes_id_seq OWNED BY public.ingredientes.id;


--
-- TOC entry 212 (class 1259 OID 263613)
-- Name: unidademedida; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.unidademedida (
    id integer NOT NULL,
    unidade character varying(20) NOT NULL,
    unidadeabreviada character varying(6)
);


ALTER TABLE public.unidademedida OWNER TO postgres;

--
-- TOC entry 211 (class 1259 OID 263612)
-- Name: unidademedida_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.unidademedida_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.unidademedida_id_seq OWNER TO postgres;

--
-- TOC entry 3355 (class 0 OID 0)
-- Dependencies: 211
-- Name: unidademedida_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.unidademedida_id_seq OWNED BY public.unidademedida.id;


--
-- TOC entry 3185 (class 2604 OID 263633)
-- Name: embalagensingredientes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.embalagensingredientes ALTER COLUMN id SET DEFAULT nextval('public.embalagensingredientes_id_seq'::regclass);


--
-- TOC entry 3187 (class 2604 OID 263653)
-- Name: estoqueingredientes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.estoqueingredientes ALTER COLUMN id SET DEFAULT nextval('public.estoqueingredientes_id_seq'::regclass);


--
-- TOC entry 3179 (class 2604 OID 263603)
-- Name: ingredientes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ingredientes ALTER COLUMN id SET DEFAULT nextval('public.ingredientes_id_seq'::regclass);


--
-- TOC entry 3184 (class 2604 OID 263616)
-- Name: unidademedida id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.unidademedida ALTER COLUMN id SET DEFAULT nextval('public.unidademedida_id_seq'::regclass);


--
-- TOC entry 3343 (class 0 OID 263630)
-- Dependencies: 214
-- Data for Name: embalagensingredientes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.embalagensingredientes (id, idingrediente, descricao, ean, idunidademedida, tipoembalagem, quantidade) FROM stdin;
1	1	PACOTE 1 KG	7890000000001	1	1	1000
2	1	PACOTE 10 KG	7890000000002	1	1	10000
\.


--
-- TOC entry 3345 (class 0 OID 263650)
-- Dependencies: 216
-- Data for Name: estoqueingredientes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.estoqueingredientes (id, idingrediente, lote, datafabricacao, datavalidade, quantidade) FROM stdin;
1	1	\N	\N	\N	10000
2	1	\N	\N	\N	500
\.


--
-- TOC entry 3339 (class 0 OID 263600)
-- Dependencies: 210
-- Data for Name: ingredientes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ingredientes (id, nome, precocusto, precocustomedio, quantidadeembalagem, status) FROM stdin;
1	FARINHA DE TRIGO	3.50	3.47	1000	0
2	ACUCAR REFINADO	2.89	2.90	1000	0
3	AMIDO DE MILHO	7.99	8.47	1000	0
\.


--
-- TOC entry 3341 (class 0 OID 263613)
-- Dependencies: 212
-- Data for Name: unidademedida; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.unidademedida (id, unidade, unidadeabreviada) FROM stdin;
1	unitario	un
2	caixa	cx
3	fardo	fardo
\.


--
-- TOC entry 3356 (class 0 OID 0)
-- Dependencies: 213
-- Name: embalagensingredientes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.embalagensingredientes_id_seq', 2, true);


--
-- TOC entry 3357 (class 0 OID 0)
-- Dependencies: 215
-- Name: estoqueingredientes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.estoqueingredientes_id_seq', 2, true);


--
-- TOC entry 3358 (class 0 OID 0)
-- Dependencies: 209
-- Name: ingredientes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ingredientes_id_seq', 3, true);


--
-- TOC entry 3359 (class 0 OID 0)
-- Dependencies: 211
-- Name: unidademedida_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.unidademedida_id_seq', 3, true);


--
-- TOC entry 3193 (class 2606 OID 263638)
-- Name: embalagensingredientes PK_embalagensingredientes; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.embalagensingredientes
    ADD CONSTRAINT "PK_embalagensingredientes" PRIMARY KEY (id);


--
-- TOC entry 3195 (class 2606 OID 263657)
-- Name: estoqueingredientes PK_estoqueingredientes; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.estoqueingredientes
    ADD CONSTRAINT "PK_estoqueingredientes" PRIMARY KEY (id);


--
-- TOC entry 3189 (class 2606 OID 263611)
-- Name: ingredientes PK_ingredientes; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ingredientes
    ADD CONSTRAINT "PK_ingredientes" PRIMARY KEY (id);


--
-- TOC entry 3191 (class 2606 OID 263618)
-- Name: unidademedida PK_unidademedida; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.unidademedida
    ADD CONSTRAINT "PK_unidademedida" PRIMARY KEY (id);


--
-- TOC entry 3196 (class 2606 OID 263639)
-- Name: embalagensingredientes FK_ingredientes; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.embalagensingredientes
    ADD CONSTRAINT "FK_ingredientes" FOREIGN KEY (idingrediente) REFERENCES public.ingredientes(id);


--
-- TOC entry 3198 (class 2606 OID 263658)
-- Name: estoqueingredientes FK_ingredientes; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.estoqueingredientes
    ADD CONSTRAINT "FK_ingredientes" FOREIGN KEY (idingrediente) REFERENCES public.ingredientes(id);


--
-- TOC entry 3197 (class 2606 OID 263644)
-- Name: embalagensingredientes FK_unidademedida; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.embalagensingredientes
    ADD CONSTRAINT "FK_unidademedida" FOREIGN KEY (idunidademedida) REFERENCES public.unidademedida(id);


-- Completed on 2024-04-12 17:21:48

--
-- PostgreSQL database dump complete
--

